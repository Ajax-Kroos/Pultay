import eyed3
import shutil
import os.path
import os

#Ruta local
PATH = os.getcwd()
LOCAL_PATH = PATH.replace('\\', '/')
#Carga de Archivos
SONG_FILE = input("Nombre completo del Archivo (con extension): ")
print("Archivo: ", SONG_FILE)
audiofile = eyed3.load(SONG_FILE)

Artist = audiofile.tag.artist = input("El Artista es: ")
Albu = audiofile.tag.album = input("Nombre del Album: ")
Titul = audiofile.tag.title = input("Titulo: ")
Gener = audiofile.tag.genre = input("Genero musical: ")
audiofile.tag.save()

artista = audiofile.tag.artist
albun = audiofile.tag.album
genero = audiofile.tag.genre
titulo = audiofile.tag.title

######        GENERO          #####
# Conversion de variable a ruta de accseso para GENERO
ruta_path11 =  LOCAL_PATH + '/Music/' + str(genero)
existenciagenero = os.path.isdir(ruta_path11)



######         ARTISTA        #####
ruta_path22 = ruta_path11 + '/' + str(artista)
existenciaartista = os.path.isdir(ruta_path22)



######          ALBUN         #####
ruta_path33 = ruta_path22 + '/' + str(albun)
existenciaalbun = os.path.isdir(ruta_path33)



######           TITLE         #####
ruta_path44 = ruta_path33 + '/' + str(titulo)
existenciatitulo = os.path.isfile(ruta_path44)

Caracteres = ('/' or '*' or '<' or '>' or ':' or '?' or '|' or '"') in Artist or Albu or Titul or Gener
Extension = ('mp3' or 'midi' or 'mid' or 'wav' or 'wma' or 'cda') in SONG_FILE

if (Extension == True):

    if (Caracteres == True):
        print("\n                No se admiten estos caracteres /*<>:?| ")
    else:
        if (existenciagenero == True):  # existe carpeta de genero
            if (existenciaartista == True):  # existe carpeta de artista
                if (existenciaalbun == True):  # existe carpeta de albun
                    if (existenciatitulo == True):  # existe la cancion
                        print("Esta archivo ya se ha clasificado anteriormente elija otro.")
                    else:
                        shutil.move(SONG_FILE, ruta_path33)
                        print("\n                   Nueva Cancion Agregada")
                        print("\n       © Todos los Derechos Reservados 2020 - CHINO")
                else:
                    os.makedirs(ruta_path33)

                    shutil.move(SONG_FILE, ruta_path33)
                    print("\n                   Nuevo Album Agregado")
                    print("\n       © Todos los Derechos Reservados 2020 - CHINO")
            else:  # no existe carpeta de artista
                os.makedirs(ruta_path22)
                os.makedirs(ruta_path33)

                shutil.move(SONG_FILE, ruta_path33)
                print("\n                   Nuevo Artista Agregado")
                print("\n       © Todos los Derechos Reservados 2020 - CHINO")
        else:  # no existe carpeta de genero
            os.makedirs(ruta_path11)
            os.makedirs(ruta_path22)
            os.makedirs(ruta_path33)

            shutil.move(SONG_FILE, ruta_path33)
            print("\n                   Nueva Seleccion Agregada")
            print("\n       © Todos los Derechos Reservados 2020 - CHINO")

else:
    print("Falta la extension del archivo")